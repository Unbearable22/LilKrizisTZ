/* Transport with request ownership. No model key or MCP endpoint exists in the browser. */
(function(root){
    const referencePattern = /№\s*\d|(?:постановлен[а-яё]*|приказ[а-яё]*|распоряжен[а-яё]*|указ[а-яё]*)\s+(?:Правительств[а-яё]*|Мин[а-яё]*|Президент[а-яё]*|[«"])|https?:\/\/|www\.|consultant\.ru|garant\.ru|pravo\.gov\.ru|(?:ЗК|ГрК|ГПК|ГК)\s*РФ|(?:земельн[а-яё]*|градостроительн[а-яё]*|гражданск[а-яё]*(?:\s+процессуальн[а-яё]*)?)\s+кодекс[а-яё]*|(?:пункт[а-яё]*|подпункт[а-яё]*|часть|части|п\.)\s*\d|закон[а-яё]*\s+(?:[«"]|от\s+\d|№\s*\d|о(?=\s)|об(?=\s)|РФ|Российск[а-яё]*)|(?:статья|статьи|статье|статью|статей|ст\.)\s*\d|\d+\s*[-‑–]\s*ФЗ|\[[^\]\n]{1,100}\]|【[^】]+】|[a-z0-9_-]{1,60}:[a-f0-9]{16}:\d+|(?:источники|нормативные основания)\s*:|КонсультантПлюс|ГАРАНТ/iu;
    const legacyNotice = 'Сохранённый ответ нужно обновить. Повторите запрос, чтобы получить ответ в новом формате.';
    function hasReferences(text){return typeof text==='string' && referencePattern.test(text);}
    function publicResult(value={}) {
        const result={};
        for(const key of ['status','answer','mode','chat_id','requestId']) {
            if(typeof value[key]==='string')result[key]=value[key];
        }
        result.missing_fields=(Array.isArray(value.missing_fields)?value.missing_fields:[])
            .filter(item=>item && typeof item.key==='string' && typeof item.label==='string' && !hasReferences(item.key) && !hasReferences(item.label))
            .map(({key,label})=>({key,label}));
        result.limitations=(Array.isArray(value.limitations)?value.limitations:[]).filter(item=>typeof item==='string' && !hasReferences(item));
        if(hasReferences(result.answer)){result.answer=legacyNotice;result.status='error';}
        return result;
    }
    function cleanChat(chat) {
        if(!chat)return chat;
        return {...chat,messages:(chat.messages || []).map(msg=>{
            const {sources,citations,trace,tasks,...message}=msg;
            if(message.role==='assistant'){
                const known=msg.legal?.sources || [];
                const privateText=hasReferences(message.text) || known.some(source=>source.title && message.text?.toLowerCase().includes(source.title.toLowerCase()));
                if(message.legal)message.legal=publicResult(message.legal);
                if(privateText){
                    message.text=legacyNotice;
                    if(message.legal){message.legal.status='error';message.legal.answer=legacyNotice;}
                }
            }
            return message;
        })};
    }
    root.LegalPrivacy={publicResult,cleanChat};
    class LegalClient {
        constructor({fetch:fetcher,onResult,onState}={}) {
            this.fetcher=fetcher || root.fetch.bind(root);
            this.onResult=onResult || (()=>{});
            this.onState=onState || (()=>{});
            this.pending=new Map();
        }
        busy(chatId){return this.pending.has(chatId);}
        cancel(chatId){
            const request=this.pending.get(chatId);
            if(request){this.pending.delete(chatId);request.controller.abort();this.onState(chatId,false);}
        }
        async submit({chatId,requestId,question,intake={},attachments=[]}){
            if(this.busy(chatId))return;
            if(attachments.length){
                await this.onResult(chatId,requestId,{status:'error',answer:'Анализ вложений пока не подключён. Уберите вложения и опишите сведения текстом; файл не использовался при анализе.',missing_fields:[]});
                return;
            }
            const controller=new AbortController();
            const request={controller};this.pending.set(chatId,request);this.onState(chatId,true);
            const timer=setTimeout(()=>controller.abort(),125000);
            try{
                const response=await this.fetcher('/api/legal-help',{
                    method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,
                    body:JSON.stringify({question,intake,chat_id:chatId})
                });
                const result=await response.json();
                if(this.pending.get(chatId)!==request)return;
                if(!response.ok)throw new Error(result.answer || 'Сервер не смог обработать запрос.');
                if(result.chat_id!==chatId)throw new Error('Ответ не соответствует исходному чату.');
                if(!['answered','partial_answer','needs_clarification','unsupported','insufficient_sources','error','invalid_request'].includes(result.status))throw new Error('Сервер вернул неизвестный результат.');
                await this.onResult(chatId,requestId,publicResult(result));
            }catch(error){
                if(this.pending.get(chatId)===request){
                    await this.onResult(chatId,requestId,publicResult({status:'error',answer:error.name==='AbortError'?'Истекло время ожидания. Автоматический повтор не выполнялся.':(error.message || 'Сервер недоступен.'),missing_fields:[]}));
                }
            }finally{
                clearTimeout(timer);
                if(this.pending.get(chatId)===request){this.pending.delete(chatId);this.onState(chatId,false);}
            }
        }
    }
    root.LegalClient=LegalClient;
    if(typeof module!=='undefined' && module.exports)module.exports={LegalClient,publicResult,cleanChat};
})(typeof window!=='undefined'?window:globalThis);
