"""Keep evidence private while preserving internal grounding checks."""
import re

REFERENCE_PATTERN = re.compile(
    r'№\s*\d|(?:постановлен\w*|приказ\w*|распоряжен\w*|указ\w*)\s+(?:Правительств\w*|Мин\w*|Президент\w*|[«"])|'
    r'https?://|www\.|consultant\.ru|garant\.ru|pravo\.gov\.ru|'
    r'\b(?:ЗК|ГрК|ГПК|ГК)\s*РФ\b|'
    r'\b(?:земельн\w*|градостроительн\w*|гражданск\w*(?:\s+процессуальн\w*)?)\s+кодекс\w*|'
    r'\b(?:пункт\w*|подпункт\w*|часть|части|п\.)\s*\d|'
    r'закон\w*\s+(?:[«"]|от\s+\d|№\s*\d|(?:о|об|РФ|Российск\w*)\b)|'
    r'\b(?:статья|статьи|статье|статью|статей|ст\.)\s*\d|'
    r'(?:№\s*)?\b\d+\s*[-‑–]\s*ФЗ\b|'
    r'\[[^\]\n]{1,100}\]|【[^】]+】|'
    r'\b[a-z0-9_-]{1,60}:[a-f0-9]{16}:\d+\b|'
    r'(?:источники|нормативные основания)\s*:|'
    r'КонсультантПлюс|ГАРАНТ', re.IGNORECASE,
)


def has_references(text, fragments=()):
    if not isinstance(text, str):return True
    if REFERENCE_PATTERN.search(text):return True
    folded=text.casefold()
    for fragment in fragments:
        for key in ('id','source_url','title'):
            value=fragment.get(key,'').split(' — часть')[0]
            if value and value.casefold() in folded:return True
    return False


def public_result(result):
    """Explicit boundary: future internal metadata cannot leak by default."""
    return {key:result[key] for key in ('status','answer','missing_fields','limitations','mode','chat_id') if key in result}
