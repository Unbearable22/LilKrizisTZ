import asyncio
import re
import logging
import time
import uuid
from .errors import LegalError
from .mcp_client import LocalLegalMCP
from .privacy import has_references

FIELD_LABELS={
    'situation':'Опишите ситуацию и известные обстоятельства',
    'goal':'Какой результат вы хотите получить',
    'region':'Регион', 'municipality':'Муниципалитет', 'address':'Полный адрес или описание местоположения',
    'object_reference':'Кадастровый номер либо координаты образуемого участка',
    'rights':'Какие права на участок имеются и на каком основании',
    'land_category':'Категория земель', 'land_use':'Вид разрешённого использования',
    'documents':'Перечислите имеющиеся документы и их даты; если нет — укажите это явно',
}
GENERAL=('situation','goal')
UNKNOWN_FACTS={'не знаю','неизвестно','не известно','неизвестен','неизвестны','нет данных','не помню','пока не знаю','пока неизвестно'}


def valid_input(question,intake):
    if not isinstance(question,str) or not question.strip() or len(question)>8000:
        raise ValueError('Введите непустой вопрос длиной до 8000 символов.')
    if not isinstance(intake,dict) or set(intake)-set(FIELD_LABELS):raise ValueError('Некорректные поля анкеты.')
    if any(not isinstance(v,str) or len(v)>3000 for v in intake.values()):raise ValueError('Значения анкеты должны быть текстом до 3000 символов.')


def validate_plan(plan):
    if not isinstance(plan,dict) or not isinstance(plan.get('tasks'),list) or len(plan['tasks'])>4:
        raise ValueError('Классификатор вернул некорректный план.')
    ids=set();tasks=[]
    for task in plan['tasks']:
        if not isinstance(task,dict) or set(task)!={'task_id','function_id','formulation','scope'}:
            raise ValueError('Неверная структура задачи.')
        if task['function_id']!='legal_help' or task['scope'] not in ('general','parcel'):
            raise ValueError('Модель выбрала неподключённую функцию или неизвестный вид задачи.')
        tid=task['task_id']
        if not isinstance(tid,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,30}',tid) or tid in ids:
            raise ValueError('Некорректные идентификаторы задач.')
        if not isinstance(task['formulation'],str) or not task['formulation'].strip() or len(task['formulation'])>8000:
            raise ValueError('Некорректная формулировка задачи.')
        ids.add(tid);tasks.append(dict(task))
    return tasks


def validate_answer(result,fragments,scope='general'):
    if not isinstance(result,dict) or not isinstance(result.get('answer'),str) or not result['answer'].strip() or len(result['answer'])>20000:
        raise LegalError('invalid_answer')
    if result.get('status','answered') not in ('answered','partial_answer','insufficient_sources'):raise LegalError('invalid_answer_status')
    if result.get('status')=='insufficient_sources':return
    if scope=='parcel' and result.get('status','answered')=='answered':raise LegalError('definitive_parcel_answer')
    citations=result.get('citations')
    available={f['id']:f for f in fragments}
    if not isinstance(citations,list) or not citations or len(citations)>6 or any(not isinstance(c,str) or c not in available for c in citations):
        raise LegalError('invalid_citations')
    limits=result.get('limitations',[])
    if not isinstance(limits,list) or any(not isinstance(v,str) or len(v)>2000 for v in limits):raise LegalError('invalid_limitations')
    if has_references(result['answer'],fragments) or any(has_references(limit,fragments) for limit in limits):
        raise LegalError('visible_references')

    if result.get('status')=='partial_answer':
        questions=result.get('missing_fields',[])
        if not isinstance(questions,list) or len(questions)>3 or any(not isinstance(k,str) or k not in FIELD_LABELS for k in questions) or len(set(questions))!=len(questions):raise LegalError('invalid_missing_fields')
        scenarios=result.get('scenarios')
        if not isinstance(scenarios,list) or not 1<=len(scenarios)<=3:raise LegalError('invalid_scenarios')
        for branch in scenarios:
            if not isinstance(branch,dict) or set(branch)!={'condition','outcome','citations'}:raise LegalError('invalid_scenarios')
            for key in ('condition','outcome'):
                if not isinstance(branch[key],str) or not branch[key].strip() or len(branch[key])>1200:raise LegalError('invalid_scenarios')
                if has_references(branch[key],fragments):raise LegalError('visible_references')
            ids=branch['citations']
            if not isinstance(ids,list) or not ids or len(ids)>6 or any(not isinstance(c,str) or c not in available for c in ids):raise LegalError('invalid_citations')


class LegalPipeline:
    def __init__(self,root,model,demo=False):
        self.root=root;self.model=model;self.demo=demo

    async def run(self,question,intake):
        started=time.monotonic();stage='input';run_id=uuid.uuid4().hex
        trace=['input.validate']
        base={'status':'error','question':question if isinstance(question,str) else '', 'tasks':[], 'missing_fields':[], 'answer':'','sources':[], 'mode':'demo' if self.demo else 'live','trace':trace,'limitations':[], 'diagnostics':{'run_id':run_id}}
        try:valid_input(question,intake)
        except ValueError as exc:return {**base,'status':'invalid_request','answer':str(exc)}
        try:
            async with asyncio.timeout(120):
                stage='classify'
                plan=await self.model.classify(question,intake)
                trace+=['llm.classify','plan.validate']
                stage='plan_validate'
                tasks=validate_plan(plan);base['tasks']=tasks
                if not tasks:
                    if plan.get('needs_clarification'):
                        return {**base,'status':'needs_clarification','answer':'Опишите юридическую задачу подробнее и укажите желаемый результат.','missing_fields':[{'key':k,'label':FIELD_LABELS[k]} for k in GENERAL]}
                    return {**base,'status':'unsupported','answer':'Сейчас подключена только юридическая помощь по земельным и имущественным вопросам. Этот запрос пока не поддерживается.'}
                answers=[];sources={};limitations=[];questions={};partial=False;unanswered=False
                for task in tasks:
                    stage='mcp_context'
                    context=await LocalLegalMCP(self.root,demo=self.demo).context(task['formulation'])
                    trace.extend(context['trace'])
                    limitations.extend(context.get('limitations',[]))
                    fragments=context['fragments']
                    if not fragments:
                        unanswered=True
                        continue
                    if not self.demo and any(f.get('demo',True) for f in fragments):raise ValueError('Учебный источник недоступен для рабочего ответа.')
                    stage='answer'
                    arguments=dict(original_question=question,formulation=task['formulation'],intake=intake,prompt=context['prompt'],fragments=fragments,scope=task['scope'])
                    result=await self.model.answer(**arguments)
                    trace+=['llm.answer','answer.validate']
                    stage='answer_validate'
                    try:validate_answer(result,fragments,scope=task['scope'])
                    except LegalError as exc:
                        if exc.code!='visible_references' or not callable(getattr(self.model,'rewrite_answer',None)):raise
                        # One presentation repair, never an unbounded agent loop or network retry.
                        stage='rewrite';trace.append('llm.rewrite')
                        result=await self.model.rewrite_answer(draft=result,**arguments)
                        stage='rewrite_validate';validate_answer(result,fragments,scope=task['scope'])
                    if result.get('status')=='insufficient_sources':
                        base['diagnostics'].update(code='insufficient_context',stage=stage)
                        unanswered=True
                        continue
                    citations=list(result['citations']);limits=result.get('limitations',[])
                    text=result['answer']
                    if result.get('status')=='partial_answer':
                        partial=True
                        text='Предварительный разбор: сведения об объекте не проверялись.\n\n'+text+'\n\nВозможные варианты:'
                        for branch in result['scenarios']:
                            text+='\n• Если '+branch['condition'].strip()+', то '+branch['outcome'].strip()
                            citations.extend(branch['citations'])
                        for key in result.get('missing_fields',[]):
                            if intake.get(key,'').strip(' .!?,').casefold() not in UNKNOWN_FACTS:questions[key]={'key':key,'label':FIELD_LABELS[key]}

                    available={f['id']:f for f in fragments}
                    for c in citations:sources[c]={k:v for k,v in available[c].items() if k!='text'}
                    limitations.extend(limits)
                    answers.append(text)
                if not answers:
                    return {**base,'status':'insufficient_sources','answer':'Недостаточно подтверждённых сведений для надёжного ответа по этому вопросу. Уточните ситуацию или обратитесь за индивидуальным разбором.'}
                if unanswered:limitations.append('Часть запроса не разобрана: для неё недостаточно подтверждённых материалов.')
                return {**base,'status':'partial_answer' if partial or unanswered else 'answered','answer':'\n\n'.join(answers),'sources':list(sources.values()),'missing_fields':list(questions.values())[:3],'limitations':list(dict.fromkeys(limitations))}
        except asyncio.CancelledError:raise
        except Exception as exc:
            code=getattr(exc,'code', 'pipeline_timeout' if isinstance(exc,TimeoutError) else 'mcp_failure' if stage=='mcp_context' else 'invalid_plan' if stage=='plan_validate' else 'internal_error')
            diagnostic={'run_id':run_id,'stage':stage,'code':code,'elapsed_seconds':round(time.monotonic()-started,2)}
            if getattr(exc,'http_status',None):diagnostic['http_status']=exc.http_status
            logging.getLogger(__name__).warning('legal_failure run=%s stage=%s code=%s elapsed=%s',run_id,stage,code,diagnostic['elapsed_seconds'])
            message='Не удалось подготовить проверенный ответ. Попробуйте повторить запрос позже.'
            if code in ('llm_timeout','pipeline_timeout'):message='Модель не успела подготовить ответ. Попробуйте повторить запрос позже.'
            elif code in ('llm_connection','llm_rate_limit','llm_http'):message='Сервис подготовки ответа временно недоступен. Попробуйте позже.'
            return {**base,'status':'error','answer':message,'sources':[],'diagnostics':diagnostic}
