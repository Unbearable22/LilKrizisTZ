const {test}=require('node:test');
const assert=require('node:assert/strict');
let LegalClient;
try{({LegalClient}=require('../groundAndLaw/legal-api.js'));}catch{}

test('request result stays bound to original chat and source message',async()=>{
 assert.equal(typeof LegalClient,'function','Клиент юридического API ещё не реализован');
 let finish;const updates=[];
 const client=new LegalClient({fetch:()=>new Promise(r=>{finish=r}),onResult:(...v)=>updates.push(v)});
 const promise=client.submit({chatId:'first',requestId:'message1',question:'Вопрос',intake:{}});
 finish({ok:true,json:async()=>({status:'answered',chat_id:'first',answer:'Ответ',sources:[]})});
 await promise;assert.equal(updates[0][0],'first');assert.equal(updates[0][1],'message1');
});

test('cancelled or deleted chat never receives a late response',async()=>{
 assert.equal(typeof LegalClient,'function');let finish;let writes=0;
 const client=new LegalClient({fetch:()=>new Promise(r=>{finish=r}),onResult:()=>writes++});
 const promise=client.submit({chatId:'gone',requestId:'m',question:'Вопрос'});
 client.cancel('gone');
 finish({ok:true,json:async()=>({status:'answered',chat_id:'gone',sources:[]})});
 await promise;assert.equal(writes,0);
});

test('API error is shown and a later retry can succeed',async()=>{
 assert.equal(typeof LegalClient,'function');let calls=0;const results=[];
 const client=new LegalClient({fetch:async()=>++calls===1?{ok:false,json:async()=>({answer:'Ошибка сервиса'})}:{ok:true,json:async()=>({status:'answered',chat_id:'a',sources:[]})},onResult:(c,m,r)=>results.push(r)});
 await client.submit({chatId:'a',requestId:'m',question:'Вопрос'});
 assert.equal(results[0].status,'error');
 await client.submit({chatId:'a',requestId:'m',question:'Вопрос'});
 assert.equal(results[1].status,'answered');
});

test('attachments and concurrent duplicate sends do not trigger ignored input or duplicate calls',async()=>{
 assert.equal(typeof LegalClient,'function');let calls=0;let finish;const results=[];
 const client=new LegalClient({fetch:()=>{calls++;return new Promise(r=>finish=r)},onResult:(c,m,r)=>results.push(r)});
 await client.submit({chatId:'a',requestId:'file',question:'Вопрос',attachments:[{name:'proof.pdf'}]});
 assert.equal(calls,0);assert.equal(results[0].status,'error');
 const first=client.submit({chatId:'a',requestId:'m',question:'Вопрос'});
 await client.submit({chatId:'a',requestId:'m',question:'Вопрос'});
 assert.equal(calls,1);
 finish({ok:true,json:async()=>({status:'answered',chat_id:'a',sources:[]})});await first;
});

test('mismatched API chat id is rejected instead of displayed',async()=>{
 assert.equal(typeof LegalClient,'function');const results=[];
 const client=new LegalClient({fetch:async()=>({ok:true,json:async()=>({status:'answered',chat_id:'other',answer:'Чужой ответ'})}),onResult:(c,m,r)=>results.push(r)});
 await client.submit({chatId:'a',requestId:'m',question:'Вопрос'});
 assert.equal(results[0].status,'error');assert.notEqual(results[0].answer,'Чужой ответ');
});

test('transport never passes private source fields to UI or persistence',async()=>{
 const updates=[];
 const client=new LegalClient({fetch:async()=>({ok:true,json:async()=>({status:'answered',chat_id:'a',answer:'Ответ без ссылок.',sources:[{title:'Секретный реестр'}],citations:['private'],trace:['mcp.read'],tasks:[{source_url:'private'}],limitations:[]})}),onResult:(c,m,r)=>updates.push(r)});
 await client.submit({chatId:'a',requestId:'m',question:'Вопрос'});
 for(const key of ['sources','citations','trace','tasks'])assert.equal(key in updates[0],false,key);
});

test('legacy assistant sources are removed without changing original user question',()=>{
 const {cleanChat}=require('../groundAndLaw/legal-api.js');
 assert.equal(typeof cleanChat,'function');
 const old={id:'old',messages:[{role:'user',text:'Что означает статья 12 ЗК РФ?',id:'u'},
 {role:'assistant',text:'См. статью 12 ЗК РФ https://example.org.',legal:{requestId:'u',status:'answered',sources:[{title:'ЗК РФ'}],trace:['mcp'],answer:'См. статью 12 ЗК РФ.'}}]};
 const cleaned=cleanChat(old);
 assert.equal(cleaned.messages[0].text,'Что означает статья 12 ЗК РФ?');
 assert.doesNotMatch(JSON.stringify(cleaned.messages[1]),/https:|ЗК РФ|sources|trace/);
 assert.equal(cleaned.messages[1].legal.requestId,'u');
});

test('additional normative references never reach public answers',()=>{
 const {publicResult}=require('../groundAndLaw/legal-api.js');
 for(const answer of ['Согласно пункту 2 указанной нормы.','Согласно ГК РФ.','Согласно Федеральному закону о садоводстве.','См. закон о садоводстве.','Основание — Закон Российской Федерации о приватизации.','Согласно Гражданскому кодексу.'])assert.equal(publicResult({status:'answered',answer}).status,'error');
});

test('generic mentions of legislation do not erase a valid answer',()=>{
 const {publicResult}=require('../groundAndLaw/legal-api.js');
 for(const answer of ['Это предусмотрено федеральным законом.','Федеральными законами могут устанавливаться дополнительные условия.'])assert.equal(publicResult({status:'answered',answer}).status,'answered');
});

test('named regulations and orders are not public answer text',()=>{
 const {publicResult}=require('../groundAndLaw/legal-api.js');
 for(const answer of ['Согласно постановлению Правительства РФ от 28.01.2006 № 47.','Согласно приказу Минэкономразвития России от 08.12.2015 № 921.'])assert.equal(publicResult({status:'answered',answer}).status,'error');
});

test('transport accepts preliminary answers and optional clarification fields',async()=>{
 const results=[];
 const client=new LegalClient({fetch:async()=>({ok:true,json:async()=>({chat_id:'a',status:'partial_answer',answer:'Если условие выполнено, можно уточнить порядок.',missing_fields:[{key:'rights',label:'Права на участок'}]})}),onResult:(c,m,r)=>results.push(r)});
 await client.submit({chatId:'a',requestId:'m',question:'Вопрос'});
 assert.equal(results[0].status,'partial_answer');assert.equal(results[0].missing_fields[0].key,'rights');
});
